package data;
public class Episodios extends Objeto{
    private String nombre;
    private String episodio;
    private String estreno;
    private String id;

    public Episodios(String nombre, String episodio, String estreno, String id){
        this.episodio = episodio;
        this.estreno = estreno;
        this.nombre = nombre;
        this.id=id;
    }
    public Episodios(String texto){
        int v = 0;
        String s ="";
        for(int i = 0;i<texto.length();i++){
            char c = texto.charAt(i);
            if(c==';'){
                switch(v){
                    case 0:
                        this.id=s;
                        s="";
                        v++;
                        break;
                    case 1:
                        this.nombre=s;
                        s="";
                        v++;
                        break;
                    case 2:
                        this.episodio=s;
                        s="";
                        v++;
                        break;
                    case 3:
                        this.estreno=s;
                        s="";
                        v++;
                        break;
                }

            }else{
                s += c;
            }
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getEpisodio() {
        return episodio;
    }

    public String getEstreno() {
        return estreno;
    }

    @Override
    public String toString() {
        return id + "_" + nombre + "_" + episodio + "_" + estreno;
    }
}


package data;

public class Objeto {
}

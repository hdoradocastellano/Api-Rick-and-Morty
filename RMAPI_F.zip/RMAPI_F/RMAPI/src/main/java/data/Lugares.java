package data;

public class Lugares extends Objeto {
    private String id;
    private String nombre;
    private String tipo;
    private String dimension;

    public Lugares(String nombre, String tipo, String dimension, String id){
        this.nombre = nombre;
        this.tipo = tipo;
        this.dimension = dimension;
        this.id=id;
    }
    public Lugares(String texto){
        int v = 0;
        String s ="";
        for(int i = 0;i<texto.length();i++){
            char c = texto.charAt(i);
            if(c==';'){
                switch(v){
                    case 0:
                        this.id=s;
                        s="";
                        v++;
                        break;
                    case 1:
                        this.nombre=s;
                        s="";
                        v++;
                        break;
                    case 2:
                        this.tipo=s;
                        s="";
                        v++;
                        break;
                    case 3:
                        this.dimension=s;
                        s="";
                        v++;
                        break;

                }

            }else{
                s += c;
            }
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getDimension() {
        return dimension;
    }

    public String getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return id + "_" + nombre + "_" + tipo + "_" + dimension;
    }
}

package data;

public class Personaje extends Objeto{
    private String nombre;
    private String especie;
    private String id;

    public Personaje(String nombre, String especie, String id){
        this.nombre = nombre;
        this.especie = especie;
        this.id = id;
    }
    public Personaje(String texto){
        int v = 0;
        String s ="";
        for(int i = 0;i<texto.length();i++){
            char c = texto.charAt(i);
            if(c==';'){
                switch(v){
                    case 0:
                        this.id=s;
                        s="";
                        v++;
                        break;
                    case 1:
                        this.nombre=s;
                        s="";
                        v++;
                        break;
                    case 2:
                        this.especie=s;
                        s="";
                        v++;
                        break;
                }

            }else{
                s += c;
            }
        }
    }
    public String getNombre() {return nombre;}
    public String getEspecie() {return especie;}

    @Override
    public String toString() {
        return id + "_" + nombre + "_" + especie;
    }
}

import api.rmapi;
import data.*;

import java.util.Scanner;

public class Main {
    static Gestor g = new Gestor();
    static Fichero f = new Fichero();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("RMapi Application");
            System.out.println("===============================================");
            System.out.println("Selecciona una de estas opciones:");
            System.out.println("1. Buscar un personaje.");
            System.out.println("2. Buscar un Lugar.");
            System.out.println("3. Buscar un Episodio.");
            System.out.println("4. Ver Detalle.");
            System.out.println("5. Crear fichero.");
            System.out.println("6. Leer fichero.");
            System.out.println("7. Salir.");
            opcion = sc.nextInt();

            run(opcion, sc);
        } while (opcion != 7);
    }

    static void run(int opcion, Scanner sc) {
        rmapi rmapi = new rmapi();

        switch (opcion) {
            case 1:
                buscarPersonaje(rmapi);
                break;
            case 2:
                buscarLugar(rmapi);
                break;
            case 3:
                buscarEpisodio(rmapi);
                break;
            case 4:
                System.out.println("Si buscas personajes introduce 1.");
                System.out.println("Si buscas lugares introduce 2.");
                System.out.println("Si buscas episodios introduce 3.");
                int busqueda = sc.nextInt();

                verDetalle(busqueda);
                break;
            case 5:
                System.out.println("Si quieres un personaje introduce 1.");
                System.out.println("Si quieres un lugar introduce 2.");
                System.out.println("Si quieres un episodio introduce 3.");
                int orden = sc.nextInt();
                verDetalle(orden);
                System.out.println("Introduce el indice de tu objeto elegido.");
                int orden2 = sc.nextInt();
                switch(orden){
                    case 1:
                        f.crearFichero(g.personajes.get(orden2), orden);
                        break;
                    case 2:
                        f.crearFichero(g.lugares.get(orden2), orden);
                        break;
                    case 3:
                        f.crearFichero(g.episodios.get(orden2), orden);
                        break;
                }
                break;
            case 6:
                f.verTextos();
                System.out.println("Introduce la ruta del archivo a convertir.");
                String ruta = sc.next();
                f.crearObjeto(ruta);
                break;

                
            default: System.out.println("Opcion no valida.");
        }
    }

    static void buscarPersonaje(rmapi rmapi) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el id");
        String s = scanner.next();
        Personaje p = rmapi.buscarPersonaje(s);

        g.addPersonaje(p);

        System.out.println(p.getNombre());
    }
    static void buscarLugar(rmapi rmapi) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el id");
        String s = scanner.next();
        Lugares l = rmapi.buscarLugar(s);

        g.addLugares(l);

        System.out.println(l.getNombre());
    }
    static void buscarEpisodio(rmapi rmapi) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el id");
        String s = scanner.next();
        Episodios e = rmapi.buscarEpisodio(s);

        g.addEpisodios(e);

        System.out.println(e.getNombre());
    }
    static void verDetalle(int i){
        switch(i){
            case 1:
                System.out.println(g.personajes + " ");
                break;
            case 2:
                System.out.println(g.lugares);
                break;
            case 3:
                System.out.println(g.episodios);
                break;
            default:
                System.out.println("Opcion no valida");
        }
    }


}
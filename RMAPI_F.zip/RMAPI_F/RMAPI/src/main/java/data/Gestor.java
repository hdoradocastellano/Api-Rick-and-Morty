package data;

import java.util.ArrayList;

public class Gestor {
    public ArrayList<Personaje> personajes;
    public ArrayList<Lugares> lugares;
    public ArrayList<Episodios> episodios;

    public Gestor(){
        this.episodios = new ArrayList<>();
        this.lugares = new ArrayList<>();
        this.personajes = new ArrayList<>();
    }

    public void addPersonaje(Personaje p){
        personajes.add(p);
    }
    public void addLugares(Lugares l){
        lugares.add(l);
    }
    public void addEpisodios(Episodios e){
        episodios.add(e);
    }

}

package data;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;

public class Fichero {
    public ArrayList<String> textos;

    public Fichero() {
        this.textos = new ArrayList<>();
    }


    public void verTextos() {
        for (String s : textos) {
            System.out.println(s);
        }
    }


    public void crearFichero(Objeto objeto, int orden) {
        String texto = "";
        Scanner sc = new Scanner(System.in);
        switch (orden) {
            case 1:
                texto += "Personaje;";
                break;
            case 2:
                texto += "Lugares;";
                break;
            case 3:
                texto += "Episodios;";
                break;
        }
        for (int i = 0; i < objeto.toString().length(); i++) {
            char c = objeto.toString().charAt(i);
            if (c == '_') {
                texto += ";";
            } else {
                texto += c;
            }

        }
        System.out.println(texto);
        textos.add(texto);
        System.out.println("Introduce la ruta del archivo");
        String ruta = sc.next();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta, true))) {
            bw.write(texto);
            bw.newLine();
            System.out.println("Texto añadido con éxito.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    public void crearObjeto(String ruta) {
        String texto = "";
        try {
            texto = Files.readString(Path.of(ruta));
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        String[] lineas = texto.split("\n");


        String tipoObjeto = "";
        String restoTexto = "";

        char c;
        for (String s : lineas) {
            int i = 0;
            do {
                c = s.charAt(i);
                if (c != ';') {
                    tipoObjeto += c;
                } else {
                    restoTexto = s.substring(i + 1);
                    break;
                }
                i++;
            } while (i < s.length() && c != ';');

            switch (tipoObjeto) {
                case "Personaje":
                    Personaje p = new Personaje(restoTexto);
                    System.out.println(p.toString());
                    tipoObjeto="";
                    restoTexto="";
                    break;
                case "Lugares":
                    Lugares l = new Lugares(restoTexto);
                    System.out.println(l.toString());
                    tipoObjeto="";
                    restoTexto="";
                    break;
                case "Episodios":
                    Episodios e = new Episodios(restoTexto);
                    System.out.println(e.toString());
                    tipoObjeto="";
                    restoTexto="";
                    break;

            }
        }
    }
}
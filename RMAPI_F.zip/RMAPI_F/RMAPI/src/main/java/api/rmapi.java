package api;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import data.Episodios;
import data.Lugares;
import data.Personaje;


import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;

public class rmapi {
    private final String baseurl;
    private HttpClient client;

    private Gson gson;
    private Type type;

    public rmapi() {
        this.baseurl = "https://rickandmortyapi.com/api/";
        this.client = HttpClient.newHttpClient();

        this.gson = new Gson();
        this.type = new TypeToken<HashMap<String, Object>>() {}.getType();
    }

    public Personaje buscarPersonaje(String i) {
        String endpoint = this.baseurl + "character/" + i;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .GET()
                .build();

        try {
            HttpResponse<String> response = this.client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString()
            );

            HashMap<String, Object> responseParsed = this.rmapiResponseToMap(response.body());
            String name = responseParsed.get("name").toString();
            String especie = responseParsed.get("species").toString();
            String id = responseParsed.get("id").toString();

            return new Personaje(name, especie, id);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return new Personaje("", "", "");
        }
    }

    public Lugares buscarLugar(String i) {

        String endpoint = this.baseurl + "location/" + i;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .GET()
                .build();

        try {
            HttpResponse<String> response = this.client.send(request, HttpResponse.BodyHandlers.ofString());


            HashMap<String, Object> responseParsed = this.rmapiResponseToMap(response.body());


            String nombre = (String) responseParsed.get("name").toString();
            String tipo = (String) responseParsed.get("type").toString();
            String dimension = (String) responseParsed.get("dimension").toString();
            String id = (String) responseParsed.get("id").toString();

            return new Lugares(nombre, tipo, dimension, id);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
            return new Lugares("", "", "", "");
        }
    }


    public Episodios buscarEpisodio(String i) {


        String endpoint = this.baseurl + "episode/" + i;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .GET()
                .build();

        try {
            HttpResponse<String> response = this.client.send(request, HttpResponse.BodyHandlers.ofString());


            HashMap<String, Object> responseParsed = this.rmapiResponseToMap(response.body());

            String nombre = (String) responseParsed.get("name").toString();
            String episodio = (String) responseParsed.get("episode").toString();
            String estreno = (String) responseParsed.get("air_date").toString();
            String id = (String) responseParsed.get("id").toString();

            return new Episodios(nombre, episodio, estreno, id);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return new Episodios("", "", null, "");
        }
    }



    private HashMap<String, Object> rmapiResponseToMap(String json) {return this.gson.fromJson(json, this.type);}


}
